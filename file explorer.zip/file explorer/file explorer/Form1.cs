﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace file_explorer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void open_button_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    webBrowser1.Url = new Uri(dialog.SelectedPath);
                    txtBox.Text = dialog.SelectedPath;
                }
            }
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            if (webBrowser1.CanGoBack)
            {
                webBrowser1.GoBack();
            }
        }

        private void forward_button_Click(object sender, EventArgs e)
        {
            if (webBrowser1.CanGoForward)
            {
                webBrowser1.GoForward();
            }
        }


        private string clipboardPath = "";  
        private bool isCutOperation = false; 

        private void copy_button_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtBox.Text))
            {
                clipboardPath = txtBox.Text;
                isCutOperation = false;
            }
        }

        private void cut_button_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtBox.Text))
            {
                clipboardPath = txtBox.Text;
                isCutOperation = true;  
            }
        }

        private async void paste_button_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(clipboardPath) && !string.IsNullOrEmpty(txtBox.Text))
            {
                string destinationPath = txtBox.Text; 

                try
                {
                    await Task.Run(() => PasteOperationAsync(destinationPath));
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
        private async Task PasteOperationAsync(string destinationPath)
        {
            if (Directory.Exists(clipboardPath))  
            {
                string newFolderPath = Path.Combine(destinationPath, Path.GetFileName(clipboardPath));
                if (isCutOperation)
                {
                    Directory.Move(clipboardPath, newFolderPath);  
                }
                else
                {
                    await CopyDirectoryUsingStreamAsync(clipboardPath, newFolderPath); 
                }
            }
            else if (File.Exists(clipboardPath))  
            {
                string newFilePath = Path.Combine(destinationPath, Path.GetFileName(clipboardPath));
                if (isCutOperation)
                {
                    File.Move(clipboardPath, newFilePath); 
                }
                else
                {
                    await CopyFileUsingStreamAsync(clipboardPath, newFilePath); 
                }
            }

            if (isCutOperation)
            {
                clipboardPath = "";
            }

            this.Invoke((MethodInvoker)delegate
            {
                MessageBox.Show("Paste operation completed.");
            });
        }

        private async Task CopyFileUsingStreamAsync(string sourceFilePath, string destFilePath)
        {
            const int bufferSize = 5000000;  

            using (FileStream sourceStream = new FileStream(sourceFilePath, FileMode.Open, FileAccess.Read))
            using (FileStream destinationStream = new FileStream(destFilePath, FileMode.Create, FileAccess.Write))
            {
                await sourceStream.CopyToAsync(destinationStream, bufferSize);  
            }
        }

        private async Task CopyDirectoryUsingStreamAsync(string sourceDir, string destDir)
        {
            Directory.CreateDirectory(destDir);

            foreach (string file in Directory.GetFiles(sourceDir))
            {
                string destFile = Path.Combine(destDir, Path.GetFileName(file));
                await CopyFileUsingStreamAsync(file, destFile);
            }

            foreach (string directory in Directory.GetDirectories(sourceDir))
            {
                string destSubDir = Path.Combine(destDir, Path.GetFileName(directory));
                await CopyDirectoryUsingStreamAsync(directory, destSubDir);  
            }
        }

        private void new_button_Click(object sender, EventArgs e)
        {
            string currentPath = txtBox.Text;

            if (Directory.Exists(currentPath))  
            {
                string newFolderName = PromptForFolderName();

                if (!string.IsNullOrEmpty(newFolderName))
                {
                    string newFolderPath = Path.Combine(currentPath, newFolderName);

                    try
                    {
                        if (!Directory.Exists(newFolderPath))
                        {
                            Directory.CreateDirectory(newFolderPath);
                            MessageBox.Show($"Folder '{newFolderName}' created successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Folder already exists!");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error creating folder: {ex.Message}");
                    }
                }
            }
            else
            {
                MessageBox.Show("Invalid directory path.");
            }
        }
        private string PromptForFolderName()
        {
            string folderName = "New Folder";
            return folderName;
        }
    }
}
