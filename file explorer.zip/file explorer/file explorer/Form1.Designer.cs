﻿namespace file_explorer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.back_button = new System.Windows.Forms.Button();
            this.forward_button = new System.Windows.Forms.Button();
            this.open_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBox = new System.Windows.Forms.TextBox();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.copy_button = new System.Windows.Forms.Button();
            this.cut_button = new System.Windows.Forms.Button();
            this.paste_button = new System.Windows.Forms.Button();
            this.new_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // back_button
            // 
            this.back_button.Location = new System.Drawing.Point(32, 12);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(83, 34);
            this.back_button.TabIndex = 0;
            this.back_button.Text = "<<";
            this.back_button.UseVisualStyleBackColor = true;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // forward_button
            // 
            this.forward_button.Location = new System.Drawing.Point(121, 12);
            this.forward_button.Name = "forward_button";
            this.forward_button.Size = new System.Drawing.Size(87, 34);
            this.forward_button.TabIndex = 1;
            this.forward_button.Text = ">>";
            this.forward_button.UseVisualStyleBackColor = true;
            this.forward_button.Click += new System.EventHandler(this.forward_button_Click);
            // 
            // open_button
            // 
            this.open_button.Location = new System.Drawing.Point(1170, 12);
            this.open_button.Name = "open_button";
            this.open_button.Size = new System.Drawing.Size(104, 34);
            this.open_button.TabIndex = 2;
            this.open_button.Text = "Open file";
            this.open_button.UseVisualStyleBackColor = true;
            this.open_button.Click += new System.EventHandler(this.open_button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(224, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "Path:";
            // 
            // txtBox
            // 
            this.txtBox.Location = new System.Drawing.Point(298, 12);
            this.txtBox.Multiline = true;
            this.txtBox.Name = "txtBox";
            this.txtBox.Size = new System.Drawing.Size(855, 34);
            this.txtBox.TabIndex = 4;
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(32, 97);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(1242, 504);
            this.webBrowser1.TabIndex = 5;
            // 
            // copy_button
            // 
            this.copy_button.Location = new System.Drawing.Point(878, 52);
            this.copy_button.Name = "copy_button";
            this.copy_button.Size = new System.Drawing.Size(93, 31);
            this.copy_button.TabIndex = 6;
            this.copy_button.Text = "copy";
            this.copy_button.UseVisualStyleBackColor = true;
            this.copy_button.Click += new System.EventHandler(this.copy_button_Click_1);
            // 
            // cut_button
            // 
            this.cut_button.Location = new System.Drawing.Point(977, 52);
            this.cut_button.Name = "cut_button";
            this.cut_button.Size = new System.Drawing.Size(85, 31);
            this.cut_button.TabIndex = 7;
            this.cut_button.Text = "cut";
            this.cut_button.UseVisualStyleBackColor = true;
            this.cut_button.Click += new System.EventHandler(this.cut_button_Click_1);
            // 
            // paste_button
            // 
            this.paste_button.Location = new System.Drawing.Point(1068, 52);
            this.paste_button.Name = "paste_button";
            this.paste_button.Size = new System.Drawing.Size(85, 31);
            this.paste_button.TabIndex = 8;
            this.paste_button.Text = "paste";
            this.paste_button.UseVisualStyleBackColor = true;
            this.paste_button.Click += new System.EventHandler(this.paste_button_Click_1);
            // 
            // new_button
            // 
            this.new_button.Location = new System.Drawing.Point(787, 52);
            this.new_button.Name = "new_button";
            this.new_button.Size = new System.Drawing.Size(85, 31);
            this.new_button.TabIndex = 9;
            this.new_button.Text = "new ";
            this.new_button.UseVisualStyleBackColor = true;
            this.new_button.Click += new System.EventHandler(this.new_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1321, 601);
            this.Controls.Add(this.new_button);
            this.Controls.Add(this.paste_button);
            this.Controls.Add(this.cut_button);
            this.Controls.Add(this.copy_button);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.txtBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.open_button);
            this.Controls.Add(this.forward_button);
            this.Controls.Add(this.back_button);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button back_button;
        private System.Windows.Forms.Button forward_button;
        private System.Windows.Forms.Button open_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBox;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Button copy_button;
        private System.Windows.Forms.Button cut_button;
        private System.Windows.Forms.Button paste_button;
        private System.Windows.Forms.Button new_button;
    }
}

